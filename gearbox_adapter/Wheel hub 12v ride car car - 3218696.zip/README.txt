Wheel hub 12v ride car car by Zupe on Thingiverse: https://www.thingiverse.com/thing:3218696

Summary:
Want to make my kids ride car two wheel drive. This is the wheel hub to connect the wheel to the motor gearbox